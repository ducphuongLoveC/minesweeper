function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-500 text-white text-2xl">
      Tailwind + React ngon lành cành đào 🍃
    </div>
  )
}

export default App
